package dataServices;

import java.util.ArrayList;

import model.Course;

public interface ICourseService {
	public ArrayList<Course> GetCourses(String studentName);
	public ArrayList<Course> GetTodayCourses(String studentName);
}
