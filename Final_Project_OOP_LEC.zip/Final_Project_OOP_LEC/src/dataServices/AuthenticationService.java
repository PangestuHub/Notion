package dataServices;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import model.Connect;
import model.GlobalSettings;
import model.User;

public class AuthenticationService implements IAuthenticationService
{
	private Connect con;
	
	@Override
	public User Login(String username, String password) 
	{
		try 
		{
			con = Connect.getConnection();
			
			String query = "Select * from user where Username = ? and UserPassword = ?";
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, username);
			st.setString(2, password);
			ResultSet rs = st.executeQuery();
			
			if(rs.next())
			{
				User user = new User();
				
				user.setUsername(username);
				user.setAddress(rs.getString("UserAddress"));
				user.setEmail(rs.getString("UserEmail"));
				user.setRole(rs.getString("UserRole"));
				user.setGender(rs.getString("UserGender"));
				user.setPhoneNumber(rs.getString("UserPhoneNumber"));
				user.setImage(rs.getBytes("UserImage"));
				
				GlobalSettings.me = user;
				
				if(GlobalSettings.me.getImage() == null)
				{
					BufferedImage bufferimage = ImageIO.read(new File("Assets/User_Icon_Black-removebg-preview.png"));
					ByteArrayOutputStream output = new ByteArrayOutputStream();
					ImageIO.write(bufferimage, "jpg", output );
					byte [] data = output.toByteArray();
					GlobalSettings.me.setImage(data);
				}
				
				return user;
			}
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		
		return null;
	}

	@Override
	public boolean Register(User user, String password) {
		try 
		{	
			InputStream in = getClass().getClassLoader().getResourceAsStream("Final_Project_OOP_LEC/Assets/User_Icon_Black-removebg-preview.png");
			String query = "insert into user values(?,?,?,?,?,?,?,?)";
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, user.getUsername());
			st.setString(2, password);
			st.setString(3, user.getEmail());
			st.setString(4, user.getAddress());
			st.setString(5, user.getPhoneNumber());
			st.setString(6, user.getGender());
			st.setString(7, user.getRole());
			st.setBlob(8, in);
			
			
			int res = st.executeUpdate();
			
			if(res > 0)
			{
				return true;
			}
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		
		return false;
	}

	

	@Override
	public boolean CheckPassword() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean CheckUsername(String username) 
	{
		try 
		{
			con = Connect.getConnection();
			
			String query = "Select username from user where Username = ?";
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, username);
			ResultSet rs = st.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		return false;
	}
	
	@Override
	public boolean UpdateProfile(User user) {
		try 
		{
			con = Connect.getConnection();
			
			String query = "UPDATE `USER`"
					+ "Set UserEmail = ?,"
					+ "UserAddress = ?,"
					+ "UserPhoneNumber = ?"
					+ "where Username = ?";
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, user.getEmail());
			st.setString(2, user.getAddress());
			st.setString(3, user.getPhoneNumber());
			st.setString(4, user.getUsername());
			
			int count = st.executeUpdate();
			
			if(count > 0)
			{
				GlobalSettings.me.setEmail(user.getEmail());
				GlobalSettings.me.setAddress(user.getAddress());
				GlobalSettings.me.setPhoneNumber(user.getPhoneNumber());
				
				return true;
			}
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		return false;
	}
	
	public AuthenticationService()
	{
		con = Connect.getConnection();
	}
}
