package dataServices;

import model.User;

public interface IAuthenticationService 
{
	public User Login(String username, String password);
	public boolean Register(User user, String password);
	public boolean CheckPassword();
	public boolean CheckUsername(String username); 
	public boolean UpdateProfile(User user); 
}
