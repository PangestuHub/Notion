package dataServices;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import model.Connect;
import model.Course;
import model.GlobalSettings;

public class CourseService implements ICourseService{
	private Connect con;
	
	@Override
	public ArrayList<Course> GetCourses(String studentName) 
	{
		ArrayList<Course> courses = new ArrayList<Course>();
		try 
		{
			String query = "";
			if(GlobalSettings.me.getRole().equals("Student"))
			{
				query ="select sc.CourseID, sc.CourseDay, cs.ClassName, cs.ClassId, c.CourseName, "
						+ "c.CreditCount, s.BeginTime, s.EndTime "
						+ "from studentcourse sc "
						+ "inner join course c on sc.CourseID = c.CourseID "
						+ "inner join Shift s on s.Shift = sc.Shift "
						+ "inner join Class cs on cs.ClassId = sc.ClassId "
						+ "where sc.Username = ?";
			}
			else if(GlobalSettings.me.getRole().equals("Lecturer"))
			{
				query ="select lc.CourseID, lc.CourseDay, cs.ClassName, cs.ClassId, c.CourseName, "
						+ "c.CreditCount, s.BeginTime, s.EndTime "
						+ "from Lecturercourse lc "
						+ "inner join course c on lc.CourseID = c.CourseID "
						+ "inner join Shift s on s.Shift = lc.Shift "
						+ "inner join Class cs on cs.ClassId = lc.ClassId "
						+ "where lc.LecturerName = ?";
			}
			
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, studentName);
			ResultSet rs = st.executeQuery();
			
			while(rs.next())
			{
				
				String courseId = rs.getString("CourseID");
				String courseName = rs.getString("CourseName");;
				String shift = rs.getString("BeginTime") + "-" + rs.getString("EndTime");
				int day = rs.getInt("CourseDay"); 
				int creditCount = rs.getInt("CreditCount");
				String className = rs.getString("ClassName");
				String classId = rs.getString("ClassId");
				
				Course newCourse = new Course();
				
				newCourse.setCourseId(courseId);
				newCourse.setCourseName(courseName);
				newCourse.setShift(shift);
				newCourse.setDay(day);
				newCourse.setCreditCount(creditCount);
				newCourse.setClassName(className);
				newCourse.setClassId(classId);
				
				courses.add(newCourse);
			}
			
			return courses;
			
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		
		return null;
	}
	
	@Override
	public ArrayList<Course> GetTodayCourses(String studentName) 
	{
		ArrayList<Course> courses = new ArrayList<Course>();
		try 
		{
			String query = "";
			if(GlobalSettings.me.getRole().equals("Student"))
			{
				query ="select sc.CourseID, sc.CourseDay, cs.ClassName, cs.ClassId, c.CourseName, "
						+ "c.CreditCount, s.BeginTime, s.EndTime "
						+ "from studentcourse sc "
						+ "inner join course c on sc.CourseID = c.CourseID "
						+ "inner join Shift s on s.Shift = sc.Shift "
						+ "inner join Class cs on cs.ClassId = sc.ClassId "
						+ "where sc.Username = ? and weekday(now()) = (sc.CourseDay - 1)";
			}
			else if(GlobalSettings.me.getRole().equals("Lecturer"))
			{
				query ="select lc.CourseID, lc.CourseDay, cs.ClassName, cs.ClassId, c.CourseName, "
						+ "c.CreditCount, s.BeginTime, s.EndTime "
						+ "from Lecturercourse lc "
						+ "inner join course c on lc.CourseID = c.CourseID "
						+ "inner join Shift s on s.Shift = lc.Shift "
						+ "inner join Class cs on cs.ClassId = lc.ClassId "
						+ "where lc.LecturerName = ? and weekday(now()) = (lc.CourseDay - 1)";
			}
			
			
			PreparedStatement st = (PreparedStatement) con.prepareStatement(query);
			
			st.setString(1, studentName);
			ResultSet rs = st.executeQuery();
			
			while(rs.next())
			{
				
				String courseId = rs.getString("CourseID");
				String courseName = rs.getString("CourseName");;
				String shift = rs.getString("BeginTime") + "-" + rs.getString("EndTime");
				int day = rs.getInt("CourseDay"); 
				int creditCount = rs.getInt("CreditCount");
				String className = rs.getString("ClassName");
				String classId = rs.getString("ClassId");
				
				Course newCourse = new Course();
				
				newCourse.setCourseId(courseId);
				newCourse.setCourseName(courseName);
				newCourse.setShift(shift);
				newCourse.setDay(day);
				newCourse.setCreditCount(creditCount);
				newCourse.setClassName(className);
				newCourse.setClassId(classId);
				
				courses.add(newCourse);
			}
			
			return courses;
			
		}
		catch (Exception e) 
		{
			showMessageDialog(null , e.getMessage());
		}
		
		return null;
	}
	
	public CourseService() 
	{
		con = Connect.getConnection();
	}

	
}
