package main;

import view.LoginView;

public class Main {
	
	public Main() {
		new LoginView();
	}
	
	public static void main(String[] args) 
	{
		new Main();
	}
}
