package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import model.Course;
import model.GlobalSettings;

public class CourseView extends BaseInternalView {
	JPanel mainPanel, courseNamePanel, courseIdPanel, classPanel, datePanel, creditPanel;
	JLabel courseNameLabel, courseIdLabel, classLabel, dateLabel, creditLabel;
	
	private Font courseNameFont = new Font("CARTOONIST", Font.PLAIN, 13);
	private Font courseDetailFont = new Font("CARTOONIST", Font.PLAIN, 12);
	private Font dateFont = new Font("CARTOONIST", Font.PLAIN, 15);
	
	private Dimension courseNamePanelSize = new Dimension(200, 40);
	private Dimension courseDetailPanelSize = new Dimension(200, 20);
	private Dimension datePanelSize = new Dimension(200, 30);
	
	private Border courseNameBorder = BorderFactory.createMatteBorder(0, 1, 1, 1, borderColor);
	private Border courseDetailBorder = BorderFactory.createMatteBorder(0, 1, 0, 1, borderColor);
	
	private Course course;
	
	private void CreateCourseName(String courseName)
	{
		courseNamePanel = new JPanel();
		courseNamePanel.setPreferredSize(courseNamePanelSize);
		courseNamePanel.setBackground(backgroundColor);
		courseNamePanel.setBorder(courseNameBorder);
		
		courseNameLabel = new JLabel(courseName);
		courseNameLabel.setForeground(foregroundColor);
		courseNameLabel.setFont(courseNameFont);
		
		courseNamePanel.add(courseNameLabel);
		
		mainPanel.add(courseNamePanel);
	}
	
	private void CreateCourseID(String courseId)
	{
		courseIdPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		courseIdPanel.setPreferredSize(courseDetailPanelSize);
		courseIdPanel.setBackground(backgroundColor);
		courseIdPanel.setBorder(courseDetailBorder);
		
		
		courseIdLabel = new JLabel(courseId);
		courseIdLabel.setForeground(foregroundColor);
		courseIdLabel.setFont(courseDetailFont);
		
		courseIdPanel.add(courseIdLabel);
		
		mainPanel.add(courseIdPanel);
	}
	
	private void CreateClass(String className)
	{
		classPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		classPanel.setPreferredSize(courseDetailPanelSize);
		classPanel.setBackground(backgroundColor);
		classPanel.setBorder(courseDetailBorder);
		
		
		classLabel = new JLabel(className);
		classLabel.setForeground(foregroundColor);
		classLabel.setFont(courseDetailFont);
		
		classPanel.add(classLabel);
		
		mainPanel.add(classPanel);
	}
	
	private void CreateCredit(int credit)
	{
		creditPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		creditPanel.setPreferredSize(courseDetailPanelSize);
		creditPanel.setBackground(backgroundColor);
		creditPanel.setBorder(courseDetailBorder);
		
		
		creditLabel = new JLabel(credit + " sks");
		creditLabel.setForeground(foregroundColor);
		creditLabel.setFont(courseDetailFont);
		
		creditPanel.add(creditLabel);
		
		mainPanel.add(creditPanel);
	}
	
	private void CreateDate(String day, String shift)
	{
		datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		datePanel.setPreferredSize(datePanelSize);
		datePanel.setBackground(backgroundColor);
		datePanel.setBorder(courseDetailBorder);
		
		dateLabel = new JLabel(day + "(" + shift + ")");
		dateLabel.setForeground(foregroundColor);
		dateLabel.setFont(dateFont);
		
		datePanel.add(dateLabel);
		
		mainPanel.add(datePanel);
	}
	
	private void CreateMainPanel(Course course)
	{
		mainPanel = new JPanel();
		mainPanel.setPreferredSize(baseSize);
		mainPanel.setBackground(backgroundColor);
		mainPanel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, borderColor));
		
		this.course = course;
		
		CreateCourseName(course.getCourseName());
		CreateCourseID(course.getCourseId());
		CreateClass(course.getClassName());
		CreateCredit(course.getCreditCount());
		CreateDate(course.getDay(), course.getShift());
		
		add(mainPanel);
	}
	public CourseView(Course course) 
	{
		CreateMainPanel(course);
		
		setVisible(true);
		setResizable(false);
	}
}
