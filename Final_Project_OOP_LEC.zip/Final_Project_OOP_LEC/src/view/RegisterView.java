package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import controller.RegisterController;


public class RegisterView extends BaseView implements ActionListener
{
	private RegisterController registerController;
	
	private JPanel mainPanel, headerPanel, contentPanel, footerPanel, loginPanel, registerPanel, usernamePanel, 
					emailPanel, phoneNumberPanel, genderPanel, genderGroupPanel, addressPanel, passwordPanel, confirmPasswordPanel, rolePanel;
	private JLabel titleLabel, usernameLabel, emailLabel, phoneNumberLabel, 
					genderLabel, addressLabel, passwordLabel, confirmPasswordLabel, roleLabel;
	private JTextField usernameField, emailField, phoneNumberField;
	private JTextArea addressArea;
	private JPasswordField passwordField, confirmPasswordField;
	private JRadioButton maleButton, femaleButton;
	private ButtonGroup genderGroup;
	private JButton loginButton, registerButton;
	private JComboBox<String> roleBox;
	
	private Color buttonColor = Color.decode("#FEFFFF");
	
	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 35);
	private Font inputFont = new Font("CARTOONIST", Font.PLAIN, 15);
	
	private Dimension frameSize = new Dimension(600,500);
	private Dimension headerPanelSize = new Dimension(550, 55);
	private Dimension contentPanelSize = new Dimension(400,325);
	private Dimension inputPanelSize = new Dimension(280,25);
	private Dimension inputFieldSize = new Dimension(150,25);
	private Dimension areaPanelSize = new Dimension(280,40);
	private Dimension inputAreaSize = new Dimension(150,40);
	private Dimension registerPanelSize = new Dimension(120,80);
	private Dimension registerButtonSize = new Dimension(100,30);
	private Dimension footerPanelSize = new Dimension(500,100);
	private Dimension loginPanelSize = new Dimension(500,80);
	private Dimension loginButtonSize = new Dimension(250,30);
	
	private void CreateUsernameLabel()
	{
		usernameLabel = new JLabel("Username");
		usernameLabel.setForeground(foregroundColor);
		usernameLabel.setFont(inputFont);
	}
	
	private void CreateUsernameField()
	{
		usernameField = new JTextField();
		usernameField.setPreferredSize(inputFieldSize);
	}
	
	private void CreateUsernamePanel()
	{
		usernamePanel = new JPanel(new BorderLayout());
		usernamePanel.setPreferredSize(inputPanelSize);
		usernamePanel.setBackground(backgroundColor);
		
		CreateUsernameLabel();
		CreateUsernameField();
		
		usernamePanel.add(usernameLabel, BorderLayout.WEST);
		usernamePanel.add(usernameField, BorderLayout.EAST);
	}
	
	private void CreateEmailLabel()
	{
		emailLabel = new JLabel("Email");
		emailLabel.setForeground(foregroundColor);
		emailLabel.setFont(inputFont);
	}
	
	private void CreateEmailField()
	{
		emailField = new JTextField();
		emailField.setPreferredSize(inputFieldSize);
	}
	
	private void CreateEmailPanel()
	{
		emailPanel = new JPanel(new BorderLayout());
		emailPanel.setPreferredSize(inputPanelSize);
		emailPanel.setBackground(backgroundColor);
		
		CreateEmailLabel();
		CreateEmailField();
		
		emailPanel.add(emailLabel, BorderLayout.WEST);
		emailPanel.add(emailField, BorderLayout.EAST);
	}
	
	private void CreatePhoneNumberLabel()
	{
		phoneNumberLabel = new JLabel("Phone Number");
		phoneNumberLabel.setForeground(foregroundColor);
		phoneNumberLabel.setFont(inputFont);
	}
	
	private void CreatePhoneNumberField()
	{
		phoneNumberField = new JTextField();
		phoneNumberField.setPreferredSize(inputFieldSize);
	}
	
	private void CreatePhoneNumberPanel()
	{
		phoneNumberPanel = new JPanel(new BorderLayout());
		phoneNumberPanel.setPreferredSize(inputPanelSize);
		phoneNumberPanel.setBackground(backgroundColor);
		
		CreatePhoneNumberLabel();
		CreatePhoneNumberField();
		
		phoneNumberPanel.add(phoneNumberLabel, BorderLayout.WEST);
		phoneNumberPanel.add(phoneNumberField, BorderLayout.EAST);
	}
	
	private void CreateGenderLabel()
	{
		genderLabel = new JLabel("Gender");
		genderLabel.setForeground(foregroundColor);
		genderLabel.setFont(inputFont);
	}
	
	private void CreateGenderGroup()
	{
		genderGroupPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		genderGroupPanel.setPreferredSize(inputFieldSize);
		genderGroupPanel.setBackground(backgroundColor);
		
		maleButton = new JRadioButton("Male");
		maleButton.setActionCommand("Male");
		maleButton.setBackground(backgroundColor);
		
		femaleButton = new JRadioButton("Female");
		femaleButton.setActionCommand("Female");
		femaleButton.setBackground(backgroundColor);
		
		genderGroup = new ButtonGroup();
		genderGroup.add(maleButton);
		genderGroup.add(femaleButton);
		
		genderGroupPanel.add(maleButton);
		genderGroupPanel.add(femaleButton);
		
		maleButton.setSelected(true);
	}
	
	private void CreateGenderPanel()
	{
		genderPanel = new JPanel(new BorderLayout());
		genderPanel.setPreferredSize(inputPanelSize);
		genderPanel.setBackground(backgroundColor);
		
		CreateGenderLabel();
		CreateGenderGroup();
		
		genderPanel.add(genderLabel, BorderLayout.WEST);
		genderPanel.add(genderGroupPanel, BorderLayout.EAST);
	}
	
	private void CreateAddressLabel()
	{
		addressLabel = new JLabel("Address");
		addressLabel.setForeground(foregroundColor);
		addressLabel.setFont(inputFont);
	}
	
	private void CreateAddressArea()
	{
		addressArea = new JTextArea();
		addressArea.setPreferredSize(inputAreaSize);
		Border border = BorderFactory.createLineBorder(borderColor);
		addressArea.setBorder(border);
	}
	
	private void CreateAddressPanel()
	{
		addressPanel = new JPanel(new BorderLayout());
		addressPanel.setPreferredSize(areaPanelSize);
		addressPanel.setBackground(backgroundColor);
		
		CreateAddressLabel();
		CreateAddressArea();
		
		addressPanel.add(addressLabel, BorderLayout.WEST);
		addressPanel.add(addressArea, BorderLayout.EAST);
	}
	
	private void CreatePasswordLabel()
	{
		passwordLabel = new JLabel("Password");
		passwordLabel.setForeground(foregroundColor);
		passwordLabel.setFont(inputFont);
	}
	
	private void CreatePasswordField()
	{
		passwordField = new JPasswordField();
		passwordField.setPreferredSize(inputFieldSize);
	}
	
	private void CreatePasswordPanel()
	{
		passwordPanel = new JPanel(new BorderLayout());
		passwordPanel.setPreferredSize(inputPanelSize);
		passwordPanel.setBackground(backgroundColor);
		
		CreatePasswordLabel();
		CreatePasswordField();
		
		passwordPanel.add(passwordLabel, BorderLayout.WEST);
		passwordPanel.add(passwordField, BorderLayout.EAST);
	}
	
	private void CreateConfirmPasswordLabel()
	{
		confirmPasswordLabel = new JLabel("Confirm Password");
		confirmPasswordLabel.setForeground(foregroundColor);
		confirmPasswordLabel.setFont(inputFont);
	}
	
	private void CreateConfirmPasswordField()
	{
		confirmPasswordField = new JPasswordField();
		confirmPasswordField.setPreferredSize(inputFieldSize);
	}
	
	private void CreateConfirmPasswordPanel()
	{
		confirmPasswordPanel = new JPanel(new BorderLayout());
		confirmPasswordPanel.setPreferredSize(inputPanelSize);
		confirmPasswordPanel.setBackground(backgroundColor);
		
		CreateConfirmPasswordLabel();
		CreateConfirmPasswordField();
		
		confirmPasswordPanel.add(confirmPasswordLabel, BorderLayout.WEST);
		confirmPasswordPanel.add(confirmPasswordField, BorderLayout.EAST);
	}
	
	private void CreateLoginButton()
	{
		loginButton = new JButton("Already have account? Sign in here!");
		loginButton.setPreferredSize(loginButtonSize);
		loginButton.setBackground(backgroundColor);
		loginButton.setForeground(primaryColor);
		loginButton.setBorder(null);
		loginButton.addActionListener(this);
	}
	
	private void CreateRegisterButton()
	{
		registerButton = new JButton("Register");
		registerButton.setBackground(buttonColor);
		registerButton.setForeground(foregroundColor);
		registerButton.setPreferredSize(registerButtonSize);
		registerButton.addActionListener(this);
	}
	
	private void CreateRoleLabel()
	{
		roleLabel = new JLabel("Role");
		roleLabel.setForeground(foregroundColor);
		roleLabel.setFont(inputFont);
	}
	
	private void CreateRoleBox()
	{
		String[] roleList = {
			"Student", "Lecturer"	
		};
		roleBox = new JComboBox<String>(roleList);
		roleBox.setPreferredSize(inputFieldSize);
		roleBox.setBackground(backgroundColor);
		roleBox.setSelectedIndex(0);
	}
	
	private void CreateRolePanel()
	{
		rolePanel = new JPanel(new BorderLayout());
		rolePanel.setPreferredSize(inputPanelSize);
		rolePanel.setBackground(backgroundColor);
		
		CreateRoleLabel();
		CreateRoleBox();
		
		rolePanel.add(roleLabel, BorderLayout.WEST);
		rolePanel.add(roleBox, BorderLayout.EAST);
	}
	
	private void CreateLoginPanel()
	{
		loginPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		loginPanel.setPreferredSize(loginPanelSize);
		loginPanel.setBackground(backgroundColor);
		
		CreateLoginButton();
		
		loginPanel.add(loginButton);
	}
	
	private void CreateRegisterPanel()
	{
		registerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 30));
		registerPanel.setPreferredSize(registerPanelSize);
		registerPanel.setBackground(backgroundColor);
		
		CreateRegisterButton();
		
		registerPanel.add(registerButton);
	}
	
	private void CreateHeaderPanel()
	{
		headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		headerPanel.setPreferredSize(headerPanelSize);
		headerPanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("Notion");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		headerPanel.add(titleLabel);
		
		mainPanel.add(headerPanel);
	}
	
	private void CreateContentPanel()
	{
		contentPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		contentPanel.setPreferredSize(contentPanelSize);
		contentPanel.setBackground(backgroundColor);
		
		CreateUsernamePanel();
		CreateEmailPanel();
		CreatePhoneNumberPanel();
		CreateGenderPanel();
		CreateAddressPanel();
		CreatePasswordPanel();
		CreateConfirmPasswordPanel();
		CreateRolePanel();
		CreateRegisterPanel();
		
		contentPanel.add(usernamePanel);
		contentPanel.add(emailPanel);
		contentPanel.add(phoneNumberPanel);
		contentPanel.add(genderPanel);
		contentPanel.add(addressPanel);
		contentPanel.add(passwordPanel);
		contentPanel.add(confirmPasswordPanel);
		contentPanel.add(rolePanel);
		contentPanel.add(registerPanel);
		
		mainPanel.add(contentPanel);
	}
	
	private void CreateFooterPanel()
	{
		footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		footerPanel.setPreferredSize(footerPanelSize);
		footerPanel.setBackground(backgroundColor);
		
		CreateLoginPanel();
		
		footerPanel.add(loginPanel);
		
		mainPanel.add(footerPanel);
	}
	
	private void CreateMainPanel()
	{
		mainPanel = new JPanel();
		mainPanel.setBackground(backgroundColor);
		
		CreateHeaderPanel();
		CreateContentPanel();
		CreateFooterPanel();
	}
	public RegisterView()
	{
		CreateMainPanel();
		
		add(mainPanel);
		
		setSize(frameSize);
		setVisible(true);
		setLocationRelativeTo(null);
		
		registerController = new RegisterController(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == loginButton)
		{
			registerController.Login();
		}
		else if(e.getSource() == registerButton)
		{
			registerController.Register();
		}
	}

	
	public ButtonGroup getGenderGroup() {
		return genderGroup;
	}

	public JTextField getUsernameField() {
		return usernameField;
	}

	public JTextField getEmailField() {
		return emailField;
	}

	public JTextField getPhoneNumberField() {
		return phoneNumberField;
	}

	public JTextArea getAddressArea() {
		return addressArea;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public JPasswordField getConfirmPasswordField() {
		return confirmPasswordField;
	}
	public JComboBox<String> getRoleBox() {
		return roleBox;
	}
	public void setRoleBox(JComboBox<String> roleBox) {
		this.roleBox = roleBox;
	}
	
}
