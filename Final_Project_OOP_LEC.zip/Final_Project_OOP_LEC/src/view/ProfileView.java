package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

import controller.ProfileController;
import model.GlobalSettings;

public class ProfileView extends BaseHomeView{
	private JPanel mainPanel, titlePanel, profileLeftPanel, profileRightPanel, profilePanel;
	private JLabel titleLabel;
	
	private JPanel usernamePanel,emailPanel, phoneNumberPanel, genderPanel, 
					genderGroupPanel, addressPanel, passwordPanel, confirmPasswordPanel, buttonPanel;
	private JLabel usernameLabel, emailLabel, phoneNumberLabel, imageLabel, genderLabel, addressLabel, passwordLabel, confirmPasswordLabel;
	private JTextField usernameField, emailField, phoneNumberField;
	private JTextArea addressArea;
	private JPasswordField passwordField, confirmPasswordField;
	private JRadioButton maleButton, femaleButton;
	private ButtonGroup genderGroup;
	
	private JButton saveButton, cancelButton;
	
	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 30);
	private Font inputFont = new Font("CARTOONIST", Font.PLAIN, 15);
	
	private Dimension mainPanelSize = new Dimension(900, 600);
	private Dimension titlePanelSize = new Dimension(900, 100);
	private Dimension profilePanelSize = new Dimension(500, 300);
	private Dimension profileLeftPanelSize = new Dimension(200, 300);
	private Dimension profileRightPanelSize = new Dimension(300, 300);
	private Dimension inputPanelSize = new Dimension(280,25);
	private Dimension inputFieldSize = new Dimension(150,25);	
	private Dimension inputAreaSize = new Dimension(150,40);
	private Dimension areaPanelSize = new Dimension(280,40);
	private Dimension buttonPanelSize = new Dimension(280,60);
	private Dimension buttonSize = new Dimension(100,40);
	
	private ProfileController profileController;
	
	private void CreateTitle()
	{
		titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 75, 25));
		titlePanel.setPreferredSize(titlePanelSize);
		titlePanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("Profile");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		titlePanel.add(titleLabel);
		
		mainPanel.add(titlePanel);
	}
	
	private void CreateUsernameLabel()
	{
		usernameLabel = new JLabel("Username");
		usernameLabel.setForeground(foregroundColor);
		usernameLabel.setFont(inputFont);
	}
	
	private void CreateUsernameField()
	{
		usernameField = new JTextField(GlobalSettings.me.getUsername());
		usernameField.setPreferredSize(inputFieldSize);
		usernameField.setEditable(false);
	}
	
	private void CreateUsernamePanel()
	{
		usernamePanel = new JPanel(new BorderLayout());
		usernamePanel.setPreferredSize(inputPanelSize);
		usernamePanel.setBackground(backgroundColor);
		
		CreateUsernameLabel();
		CreateUsernameField();
		
		usernamePanel.add(usernameLabel, BorderLayout.WEST);
		usernamePanel.add(usernameField, BorderLayout.EAST);
	}
	
	private void CreateEmailLabel()
	{
		emailLabel = new JLabel("Email");
		emailLabel.setForeground(foregroundColor);
		emailLabel.setFont(inputFont);
	}
	
	private void CreateEmailField()
	{
		emailField = new JTextField(GlobalSettings.me.getEmail());
		emailField.setPreferredSize(inputFieldSize);
	}
	
	private void CreateEmailPanel()
	{
		emailPanel = new JPanel(new BorderLayout());
		emailPanel.setPreferredSize(inputPanelSize);
		emailPanel.setBackground(backgroundColor);
		
		CreateEmailLabel();
		CreateEmailField();
		
		emailPanel.add(emailLabel, BorderLayout.WEST);
		emailPanel.add(emailField, BorderLayout.EAST);
	}
	
	private void CreatePhoneNumberLabel()
	{
		phoneNumberLabel = new JLabel("Phone Number");
		phoneNumberLabel.setForeground(foregroundColor);
		phoneNumberLabel.setFont(inputFont);
	}
	
	private void CreatePhoneNumberField()
	{
		phoneNumberField = new JTextField(GlobalSettings.me.getPhoneNumber());
		phoneNumberField.setPreferredSize(inputFieldSize);
	}
	
	private void CreatePhoneNumberPanel()
	{
		phoneNumberPanel = new JPanel(new BorderLayout());
		phoneNumberPanel.setPreferredSize(inputPanelSize);
		phoneNumberPanel.setBackground(backgroundColor);
		
		CreatePhoneNumberLabel();
		CreatePhoneNumberField();
		
		phoneNumberPanel.add(phoneNumberLabel, BorderLayout.WEST);
		phoneNumberPanel.add(phoneNumberField, BorderLayout.EAST);
	}
	
	private void CreateGenderLabel()
	{
		genderLabel = new JLabel("Gender");
		genderLabel.setForeground(foregroundColor);
		genderLabel.setFont(inputFont);
	}
	
	private void CreateGenderGroup()
	{
		genderGroupPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		genderGroupPanel.setPreferredSize(inputFieldSize);
		genderGroupPanel.setBackground(backgroundColor);
		
		maleButton = new JRadioButton("Male");
		maleButton.setActionCommand("Male");
		maleButton.setBackground(backgroundColor);
		
		femaleButton = new JRadioButton("Female");
		femaleButton.setActionCommand("Female");
		femaleButton.setBackground(backgroundColor);
		
		genderGroup = new ButtonGroup();
		genderGroup.add(maleButton);
		genderGroup.add(femaleButton);
		
		genderGroupPanel.add(maleButton);
		genderGroupPanel.add(femaleButton);
		
		maleButton.setSelected(true);
	}
	
	private void CreateGenderPanel()
	{
		genderPanel = new JPanel(new BorderLayout());
		genderPanel.setPreferredSize(inputPanelSize);
		genderPanel.setBackground(backgroundColor);
		
		CreateGenderLabel();
		CreateGenderGroup();
		
		genderPanel.add(genderLabel, BorderLayout.WEST);
		genderPanel.add(genderGroupPanel, BorderLayout.EAST);
	}
	
	private void CreateAddressLabel()
	{
		addressLabel = new JLabel("Address");
		addressLabel.setForeground(foregroundColor);
		addressLabel.setFont(inputFont);
	}
	
	private void CreateAddressArea()
	{
		addressArea = new JTextArea(GlobalSettings.me.getAddress());
		addressArea.setPreferredSize(inputAreaSize);
		Border border = BorderFactory.createLineBorder(borderColor);
		addressArea.setBorder(border);
	}
	
	private void CreateAddressPanel()
	{
		addressPanel = new JPanel(new BorderLayout());
		addressPanel.setPreferredSize(areaPanelSize);
		addressPanel.setBackground(backgroundColor);
		
		CreateAddressLabel();
		CreateAddressArea();
		
		addressPanel.add(addressLabel, BorderLayout.WEST);
		addressPanel.add(addressArea, BorderLayout.EAST);
	}
	
	private void CreatePasswordLabel()
	{
		passwordLabel = new JLabel("Password");
		passwordLabel.setForeground(foregroundColor);
		passwordLabel.setFont(inputFont);
	}
	
	private void CreatePasswordField()
	{
		passwordField = new JPasswordField();
		passwordField.setEditable(false);
		passwordField.setPreferredSize(inputFieldSize);
	}
	
	private void CreatePasswordPanel()
	{
		passwordPanel = new JPanel(new BorderLayout());
		passwordPanel.setPreferredSize(inputPanelSize);
		passwordPanel.setBackground(backgroundColor);
		
		CreatePasswordLabel();
		CreatePasswordField();
		
		passwordPanel.add(passwordLabel, BorderLayout.WEST);
		passwordPanel.add(passwordField, BorderLayout.EAST);
	}
	
	private void CreateConfirmPasswordLabel()
	{
		confirmPasswordLabel = new JLabel("Confirm Password");
		confirmPasswordLabel.setForeground(foregroundColor);
		confirmPasswordLabel.setFont(inputFont);
	}
	
	private void CreateConfirmPasswordField()
	{
		confirmPasswordField = new JPasswordField();
		confirmPasswordField.setPreferredSize(inputFieldSize);
		confirmPasswordField.setEditable(false);
	}
	
	private void CreateConfirmPasswordPanel()
	{
		confirmPasswordPanel = new JPanel(new BorderLayout());
		confirmPasswordPanel.setPreferredSize(inputPanelSize);
		confirmPasswordPanel.setBackground(backgroundColor);
		
		CreateConfirmPasswordLabel();
		CreateConfirmPasswordField();
		
		confirmPasswordPanel.add(confirmPasswordLabel, BorderLayout.WEST);
		confirmPasswordPanel.add(confirmPasswordField, BorderLayout.EAST);
	}
	
	private void CreateSaveButton()
	{
		saveButton = new JButton("Save");
		saveButton.setPreferredSize(buttonSize);
		saveButton.setBackground(buttonColor);
		saveButton.setForeground(backgroundColor);
		saveButton.addActionListener(this);
	}
	
	private void CreateCancelButton()
	{
		cancelButton = new JButton("Cancel");
		cancelButton.setPreferredSize(buttonSize);
		cancelButton.setBackground(redColor);
		cancelButton.setForeground(backgroundColor);
		cancelButton.addActionListener(this);
	}
	
	private void CreateButtonPanel()
	{
		buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 25, 20));
		buttonPanel.setPreferredSize(buttonPanelSize);
		buttonPanel.setBackground(backgroundColor);
		
		CreateSaveButton();
		CreateCancelButton();
		
		buttonPanel.add(cancelButton);
		buttonPanel.add(saveButton);
	}
	
	
	private void CreateProfileLeftPanel()
	{
		profileLeftPanel = new JPanel(new FlowLayout());
		profileLeftPanel.setPreferredSize(profileLeftPanelSize);
		profileLeftPanel.setBackground(backgroundColor);
		
		ImageIcon icon = new ImageIcon(GlobalSettings.me.getImage());
	    Image imgIcon = icon.getImage();
	    Image scaledImg = imgIcon.getScaledInstance(200, 300, Image.SCALE_SMOOTH);
	    ImageIcon newImage = new ImageIcon(scaledImg);
	    
	    imageLabel = new JLabel();
	    imageLabel.setPreferredSize(profileLeftPanelSize);
	    imageLabel.setIcon(newImage);
	    
	    profileLeftPanel.add(imageLabel);
	}
	
	private void CreateProfileRightPanel()
	{
		profileRightPanel = new JPanel(new FlowLayout());
		profileRightPanel.setPreferredSize(profileRightPanelSize);
		profileRightPanel.setBackground(backgroundColor);
		
		CreateUsernamePanel();
		CreateEmailPanel();
		CreatePhoneNumberPanel();
		CreateAddressPanel();
		CreateGenderPanel();
		CreatePasswordPanel();
		CreateConfirmPasswordPanel();
		CreateButtonPanel();
		
		profileRightPanel.add(usernamePanel);
		profileRightPanel.add(emailPanel);
		profileRightPanel.add(phoneNumberPanel);
		profileRightPanel.add(genderPanel);
		profileRightPanel.add(addressPanel);
		profileRightPanel.add(passwordPanel);
		profileRightPanel.add(confirmPasswordPanel);
		profileRightPanel.add(buttonPanel);
	}
	
	private void CreateProfilePanel()
	{
		profilePanel = new JPanel(new BorderLayout());
		profilePanel.setPreferredSize(profilePanelSize);
		profilePanel.setBackground(backgroundColor);
		
		CreateProfileLeftPanel();
		CreateProfileRightPanel();
		
		profilePanel.add(profileLeftPanel, BorderLayout.WEST);
		profilePanel.add(profileRightPanel, BorderLayout.EAST);
		
		mainPanel.add(profilePanel);
	}
	
	private void CreateMainPanel()
	{
		mainPanel = new JPanel();
		mainPanel.setPreferredSize(mainPanelSize);
		mainPanel.setBackground(backgroundColor);
		
		CreateTitle();
		CreateProfilePanel();
	}
	
	public ProfileView() {
		profileButton.setForeground(primaryColor);
		CreateMainPanel();
		contentPanel.add(mainPanel);
		
		profileController = new ProfileController(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == logoutButton)
		{
			baseHomeController.NavigateToLogin();
		}
		else if(e.getSource() == coursesButton)
		{
			baseHomeController.NavigateToCourses();
		}
		else if(e.getSource() == profileButton)
		{
			baseHomeController.NavigateToProfile();
		}
		else if(e.getSource() == dashboardButton)
		{
			baseHomeController.NavigateToDashboard();
		}
		else if(e.getSource() == cancelButton)
		{
			profileController.SetToDefault();
		}
		else if(e.getSource() == saveButton)
		{
			profileController.UpdateProfile();
		}
	}

	public JTextField getUsernameField() {
		return usernameField;
	}
	public void setUsernameField(JTextField usernameField) {
		this.usernameField = usernameField;
	}
	public JTextField getEmailField() {
		return emailField;
	}
	public void setEmailField(JTextField emailField) {
		this.emailField = emailField;
	}
	public JTextField getPhoneNumberField() {
		return phoneNumberField;
	}
	public void setPhoneNumberField(JTextField phoneNumberField) {
		this.phoneNumberField = phoneNumberField;
	}
	public JTextArea getAddressArea() {
		return addressArea;
	}
	public void setAddressArea(JTextArea addressArea) {
		this.addressArea = addressArea;
	}
}
