package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JInternalFrame;


public class BaseInternalView extends JInternalFrame{
	
	protected Color backgroundColor = Color.decode("#FFFFFF");
	protected Color foregroundColor = Color.decode("#47252A");
	protected Color primaryColor = Color.decode("#0B20F5");
	protected Color buttonColor = Color.decode("#4A65FA");
	protected Color redColor = Color.decode("#db1a1a");
	protected Color borderColor = Color.decode("#9CA6CE");
	protected Dimension baseSize = new Dimension(200, 160);
	
	public BaseInternalView() 
	{
		((javax.swing.plaf.basic.BasicInternalFrameUI)this.getUI()).setNorthPane(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		setBorder(null);
		setSize(baseSize);
		
	}
}
