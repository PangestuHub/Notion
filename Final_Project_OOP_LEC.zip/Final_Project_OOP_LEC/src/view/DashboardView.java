package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.CoursesController;
import controller.DashboardController;
import model.Course;

public class DashboardView extends BaseHomeView{

	private JPanel mainPanel, titlePanel, datePanel, coursesPanel, coursePanel;
	private JLabel titleLabel, dateLabel;
	
	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 30);
	private Font dateFont = new Font("CARTOONIST", Font.PLAIN, 20);
	
	private Dimension mainPanelSize = new Dimension(900, 600);
	private Dimension titlePanelSize = new Dimension(900, 60);
	private Dimension datePanelSize = new Dimension(900, 40);
	private Dimension coursesPanelSize = new Dimension(900, 500);
	private Dimension coursePanelSize = new Dimension(200, 150);
	
	private ArrayList<Course> courses = new ArrayList<>();
	
	private DashboardController dashboardController;
	
	private void CreateTitle()
	{
		titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 25));
		titlePanel.setPreferredSize(titlePanelSize);
		titlePanel.setBackground(backgroundColor);
		
		datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 10));
		datePanel.setPreferredSize(datePanelSize);
		datePanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("My Schedule");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		DateTimeFormatter dateTimeFormater = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
		LocalDateTime now = LocalDateTime.now();
		
		dateLabel = new JLabel(dateTimeFormater.format(now).toString());
		dateLabel.setFont(dateFont);
		dateLabel.setForeground(foregroundColor);
		
		titlePanel.add(titleLabel);
		datePanel.add(dateLabel);
		
		mainPanel.add(titlePanel);
		mainPanel.add(datePanel);
	}
	
	private void CreateCoursesPanel()
	{
		coursesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 20));
		coursesPanel.setPreferredSize(coursesPanelSize);
		coursesPanel.setBackground(backgroundColor);
		
		coursePanel = new JPanel(new FlowLayout());
		coursePanel.setPreferredSize(coursePanelSize);
		coursePanel.setBackground(backgroundColor);
		coursePanel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, borderColor));
		
		
		courses = dashboardController.GetTodayCourses();
		
		for(Course course : courses)
		{
			coursesPanel.add(new CourseView(course));
		}
		
		mainPanel.add(coursesPanel);
	}

	
	private void CreateMainPanel()
	{
		mainPanel = new JPanel();
		mainPanel.setPreferredSize(mainPanelSize);
		mainPanel.setBackground(backgroundColor);
		
		CreateTitle();
		CreateCoursesPanel();
	}
	
	public DashboardView() 
	{
		dashboardController = new DashboardController(this);
		dashboardButton.setForeground(primaryColor);
		CreateMainPanel();
		contentPanel.add(mainPanel);	
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == logoutButton)
		{
			baseHomeController.NavigateToLogin();
		}
		else if(e.getSource() == coursesButton)
		{
			baseHomeController.NavigateToCourses();
		}
		else if(e.getSource() == profileButton)
		{
			baseHomeController.NavigateToProfile();
		}
	}

}
