package view;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.BaseHomeController;
import model.GlobalSettings;

public class BaseHomeView extends BaseView implements ActionListener{
	
	private JPanel navBarPanel, titlePanel, informationPanel, informationLeftPanel, imagePanel,
					informationRightPanel, namePanel, rolePanel, featuresPanel, logoutPanel, coursesPanel, profilePanel, dashboardPanel;
	protected JPanel basePanel, contentPanel;
	private JLabel titleLabel, nameLabel, roleLabel, imageLabel;
	protected JButton dashboardButton, logoutButton, coursesButton, profileButton;

	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 35);
	private Font informationFont = new Font("CARTOONIST", Font.PLAIN, 15);
	private Font featuresFont = new Font("CARTOONIST", Font.PLAIN, 20);
	
	private Dimension NavBarSize = new Dimension(200, 600);
	private Dimension contentPanelSize = new Dimension(900, 600);
	private Dimension titlePanelSize = new Dimension(150, 100);
	private Dimension informationPanelSize = new Dimension(180, 100);
	private Dimension informationLeftPanelSize = new Dimension(70, 90);
	private Dimension informationRightPanelSize = new Dimension(100, 70);
	private Dimension informationDetailPanelSize = new Dimension(100, 30);
	private Dimension featuresPanelSize = new Dimension(150, 300);
	private Dimension featuresDetailPanelSize = new Dimension(150, 60);
	private Dimension featuresDetailSize = new Dimension(150, 50);
	
	protected BaseHomeController baseHomeController;
	
	
	private void CreateTitle()
	{
		titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		titlePanel.setPreferredSize(titlePanelSize);
		titlePanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("Notion");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		titlePanel.add(titleLabel);
		
		navBarPanel.add(titlePanel);
	}
	
	private void CreateInformation()
	{
		informationPanel = new JPanel(new BorderLayout());
		informationPanel.setPreferredSize(informationPanelSize);
		informationPanel.setBackground(backgroundColor);
		
		informationLeftPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		informationLeftPanel.setPreferredSize(informationLeftPanelSize);
		informationLeftPanel.setBackground(backgroundColor);
		
		informationRightPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		informationRightPanel.setPreferredSize(informationRightPanelSize);
		informationRightPanel.setBackground(backgroundColor);
		
		namePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		namePanel.setPreferredSize(informationDetailPanelSize);
		namePanel.setBackground(backgroundColor);
		
		imagePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		imagePanel.setPreferredSize(informationLeftPanelSize);
		imagePanel.setBackground(backgroundColor);
		
		rolePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		rolePanel.setPreferredSize(informationDetailPanelSize);
		rolePanel.setBackground(backgroundColor);
		
		ImageIcon icon = new ImageIcon(GlobalSettings.me.getImage());
		
		Image imgIcon = icon.getImage();
		Image scaledImg = imgIcon.getScaledInstance(75, 85, Image.SCALE_SMOOTH);
		ImageIcon newImage = new ImageIcon(scaledImg);
	    
	    imageLabel = new JLabel();
	    imageLabel.setPreferredSize(informationLeftPanelSize);
	    imageLabel.setIcon(newImage);
		
		nameLabel = new JLabel(GlobalSettings.me.getUsername());
		nameLabel.setFont(informationFont);
		nameLabel.setForeground(foregroundColor);
		
		roleLabel = new JLabel(GlobalSettings.me.getRole());
		roleLabel.setFont(informationFont);
		roleLabel.setForeground(foregroundColor);
		
		namePanel.add(nameLabel);
		rolePanel.add(roleLabel);
		imagePanel.add(imageLabel);
		
		informationLeftPanel.add(imagePanel);
		
		informationRightPanel.add(namePanel);
		informationRightPanel.add(rolePanel);
		
		informationPanel.add(informationLeftPanel, BorderLayout.WEST);
		informationPanel.add(informationRightPanel, BorderLayout.EAST);
		
		navBarPanel.add(informationPanel);
	}
	
	private void CreateFeatures()
	{
		featuresPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		featuresPanel.setPreferredSize(featuresPanelSize);
		featuresPanel.setBackground(backgroundColor);
		
		dashboardPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		dashboardPanel.setPreferredSize(featuresDetailPanelSize);
		dashboardPanel.setBackground(backgroundColor);
		
		logoutPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		logoutPanel.setPreferredSize(featuresDetailPanelSize);
		logoutPanel.setBackground(backgroundColor);
		
		coursesPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		coursesPanel.setPreferredSize(featuresDetailPanelSize);
		coursesPanel.setBackground(backgroundColor);
		
		profilePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		profilePanel.setPreferredSize(featuresDetailPanelSize);
		profilePanel.setBackground(backgroundColor);
		
		dashboardButton = new JButton("Dashboard");
		dashboardButton.setPreferredSize(featuresDetailSize);
		dashboardButton.setBackground(backgroundColor);
		dashboardButton.setForeground(foregroundColor);
		dashboardButton.setFont(featuresFont);
		dashboardButton.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, borderColor));
		dashboardButton.addActionListener(this);
		
		logoutButton = new JButton("Logout");
		logoutButton.setPreferredSize(featuresDetailSize);
		logoutButton.setBackground(backgroundColor);
		logoutButton.setForeground(foregroundColor);
		logoutButton.setFont(featuresFont);
		logoutButton.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, borderColor));
		logoutButton.addActionListener(this);
		
		coursesButton = new JButton("Courses");
		coursesButton.setPreferredSize(featuresDetailSize);
		coursesButton.setBackground(backgroundColor);
		coursesButton.setForeground(foregroundColor);
		coursesButton.setFont(featuresFont);
		coursesButton.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, borderColor));
		coursesButton.addActionListener(this);
		
		profileButton = new JButton("Profile");
		profileButton.setPreferredSize(featuresDetailSize);
		profileButton.setBackground(backgroundColor);
		profileButton.setForeground(foregroundColor);
		profileButton.setFont(featuresFont);
		profileButton.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, borderColor));
		profileButton.addActionListener(this);
		
		dashboardPanel.add(dashboardButton);
		coursesPanel.add(coursesButton);
		profilePanel.add(profileButton);
		logoutPanel.add(logoutButton);
		
		featuresPanel.add(dashboardPanel);
		featuresPanel.add(coursesPanel);
		featuresPanel.add(profilePanel);
		featuresPanel.add(logoutPanel);
		
		navBarPanel.add(featuresPanel);
	}
	
	private void CreateNavBarPanel()
	{
		navBarPanel = new JPanel(new FlowLayout());
		navBarPanel.setPreferredSize(NavBarSize);
		navBarPanel.setBackground(backgroundColor);
		navBarPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 2, borderColor));
		
		CreateTitle();
		CreateInformation();
		CreateFeatures();
	}
	
	private void CreateMainPanel()
	{
		basePanel = new JPanel(new BorderLayout());
		basePanel.setPreferredSize(baseSize);
		basePanel.setBackground(backgroundColor);
		
		contentPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		contentPanel.setPreferredSize(contentPanelSize);
		contentPanel.setBackground(backgroundColor);
		
		CreateNavBarPanel();
		
		basePanel.add(navBarPanel, BorderLayout.WEST);
		basePanel.add(contentPanel, BorderLayout.EAST);
	}
	
	public BaseHomeView()
	{
		CreateMainPanel();
		
		setSize(baseSize);
		add(basePanel);
		setLocationRelativeTo(null);
		setVisible(true);
		
		baseHomeController = new BaseHomeController(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == logoutButton)
		{
			baseHomeController.NavigateToLogin();
		}
		else if(e.getSource() == coursesButton)
		{
			baseHomeController.NavigateToCourses();
		}
		else if(e.getSource() == profileButton)
		{
			baseHomeController.NavigateToProfile();
		}
		else if(e.getSource() == dashboardButton)
		{
			baseHomeController.NavigateToProfile();
		}
	}
}
