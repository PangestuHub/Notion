package view;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.metal.MetalLookAndFeel;



public class BaseView extends JFrame
{
	protected Color backgroundColor = Color.decode("#FFFFFF");
	protected Color foregroundColor = Color.decode("#47252A");
	protected Color primaryColor = Color.decode("#0B20F5");
	protected Color buttonColor = Color.decode("#4A65FA");
	protected Color redColor = Color.decode("#db1a1a");
	protected Color borderColor = Color.decode("#9CA6CE");
	protected Dimension baseSize = new Dimension(1100,600);
	
	public BaseView()
	{
		setTitle("Notion");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setUndecorated(true);
		getRootPane().setWindowDecorationStyle( JRootPane.INFORMATION_DIALOG);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
	}
}
