package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.LoginController;

public class LoginView extends BaseView implements ActionListener
{
	private LoginController loginController;
	
	private JPanel mainPanel, headerPanel, contentPanel, footerPanel, usernamePanel, passwordPanel, loginPanel, registerPanel;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private JLabel titleLabel, usernameLabel, passwordLabel;
	private JButton loginButton, registerButton;
	
	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 35);
	private Font inputFont = new Font("CARTOONIST", Font.PLAIN, 15);
	
	private Dimension headerPanelSize = new Dimension(550,150);
	private Dimension contentPanelSize = new Dimension(300,200);
	private Dimension inputPanelSize = new Dimension(250,30);
	private Dimension inputFieldSize = new Dimension(120,30);
	private Dimension loginPanelSize = new Dimension(100,80);
	private Dimension loginButtonSize = new Dimension(100,30);
	private Dimension footerPanelSize = new Dimension(500,100);
	private Dimension registerPanelSize = new Dimension(300,80);
	private Dimension registerButtonSize = new Dimension(250,30);
	
	private void CreateUsernameLabel()
	{
		usernameLabel = new JLabel("Username");
		usernameLabel.setForeground(foregroundColor);
		usernameLabel.setFont(inputFont);
	}
	
	private void CreateUsernameField()
	{
		usernameField = new JTextField();
		usernameField.setPreferredSize(inputFieldSize);
	}
	
	private void CreateUsernamePanel()
	{
		usernamePanel = new JPanel(new BorderLayout());
		usernamePanel.setPreferredSize(inputPanelSize);
		usernamePanel.setBackground(backgroundColor);
		
		CreateUsernameLabel();
		CreateUsernameField();
		
		usernamePanel.add(usernameLabel, BorderLayout.WEST);
		usernamePanel.add(usernameField, BorderLayout.EAST);
	}
	
	private void CreatePasswordLabel()
	{
		passwordLabel = new JLabel("Password");
		passwordLabel.setForeground(foregroundColor);
		passwordLabel.setFont(inputFont);
	}
	
	private void CreatePasswordField()
	{
		passwordField = new JPasswordField();
		passwordField.setPreferredSize(inputFieldSize);
	}
	
	private void CreatePasswordPanel()
	{
		passwordPanel = new JPanel(new BorderLayout());
		passwordPanel.setPreferredSize(inputPanelSize);
		passwordPanel.setBackground(backgroundColor);
		
		CreatePasswordLabel();
		CreatePasswordField();
		
		passwordPanel.add(passwordLabel, BorderLayout.WEST);
		passwordPanel.add(passwordField, BorderLayout.EAST);
	}
	
	private void CreateLoginButton()
	{
		loginButton = new JButton("Login");
		loginButton.setPreferredSize(loginButtonSize);
		loginButton.setBackground(backgroundColor);
		loginButton.setForeground(foregroundColor);
		loginButton.addActionListener(this);
	}
	
	private void CreateRegisterButton()
	{
		registerButton = new JButton("Don't have account? sign up here");
		registerButton.setBackground(backgroundColor);
		registerButton.setForeground(primaryColor);
		registerButton.setPreferredSize(registerButtonSize);
		registerButton.setBorder(null);
		registerButton.addActionListener(this);
	}
	
	private void CreateLoginPanel()
	{
		loginPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 30));
		loginPanel.setPreferredSize(loginPanelSize);
		loginPanel.setBackground(backgroundColor);
		
		CreateLoginButton();
		
		loginPanel.add(loginButton);
	}
	
	private void CreateRegisterPanel()
	{
		registerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		registerPanel.setPreferredSize(registerPanelSize);
		registerPanel.setBackground(backgroundColor);
		
		CreateRegisterButton();
		
		registerPanel.add(registerButton);
	}
	
	private void CreateHeaderPanel()
	{
		headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 100, 50));
		headerPanel.setPreferredSize(headerPanelSize);
		headerPanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("Notion");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		headerPanel.add(titleLabel);
		
		mainPanel.add(headerPanel);
	}
	
	private void CreateContentPanel()
	{
		contentPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		contentPanel.setPreferredSize(contentPanelSize);
		contentPanel.setBackground(backgroundColor);
		
		CreateUsernamePanel();
		CreatePasswordPanel();
		CreateLoginPanel();
		
		contentPanel.add(usernamePanel);
		contentPanel.add(passwordPanel);
		contentPanel.add(loginPanel);
		
		mainPanel.add(contentPanel);
	}
	
	private void CreateFooterPanel()
	{
		footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		footerPanel.setPreferredSize(footerPanelSize);
		footerPanel.setBackground(backgroundColor);
		
		CreateRegisterPanel();
		
		footerPanel.add(registerPanel);
		
		mainPanel.add(footerPanel);
	}
	
	private void CreateMainPanel()
	{
		mainPanel = new JPanel();
		mainPanel.setBackground(backgroundColor);
		
		CreateHeaderPanel();
		CreateContentPanel();
		CreateFooterPanel();
		
	}
	
	public LoginView()
	{
		CreateMainPanel();	
		add(mainPanel);
		
		setSize(new Dimension(600, 500));
		setLocationRelativeTo(null);
		setVisible(true);
		
		
		
		loginController = new LoginController(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == loginButton)
		{
			loginController.Login();
		}
		else if(e.getSource() == registerButton)
		{
			loginController.Register();
		}
	}

	public JTextField getUsernameField() {
		return usernameField;
	}

	public void setUsernameField(JTextField usernameField) {
		this.usernameField = usernameField;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(JPasswordField passwordField) {
		this.passwordField = passwordField;
	}
	
	
}
