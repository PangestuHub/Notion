package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.CoursesController;
import model.Course;

public class CoursesView extends BaseHomeView{
	
	private JPanel mainPanel, titlePanel, coursesPanel, coursePanel;
	private JLabel titleLabel;
	
	private Font titleFont = new Font("CARTOONIST", Font.PLAIN, 30);
	
	private Dimension mainPanelSize = new Dimension(900, 600);
	private Dimension titlePanelSize = new Dimension(900, 100);
	private Dimension coursesPanelSize = new Dimension(900, 500);
	private Dimension coursePanelSize = new Dimension(200, 150);
	
	private ArrayList<Course> courses = new ArrayList<>();
	
	private CoursesController coursesController;
	
	private void CreateTitle()
	{
		titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 25));
		titlePanel.setPreferredSize(titlePanelSize);
		titlePanel.setBackground(backgroundColor);
		
		titleLabel = new JLabel("My Courses");
		titleLabel.setFont(titleFont);
		titleLabel.setForeground(primaryColor);
		
		titlePanel.add(titleLabel);
		
		mainPanel.add(titlePanel);
	}
	
	private void CreateCoursesPanel()
	{
		coursesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 50, 20));
		coursesPanel.setPreferredSize(coursesPanelSize);
		coursesPanel.setBackground(backgroundColor);
		
		coursePanel = new JPanel(new FlowLayout());
		coursePanel.setPreferredSize(coursePanelSize);
		coursePanel.setBackground(backgroundColor);
		coursePanel.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, borderColor));
		
		
		courses = coursesController.GetCourses();
		
		
		for(Course course : courses)
		{
			coursesPanel.add(new CourseView(course));
		}
		
		mainPanel.add(coursesPanel);
	}

	
	private void CreateMainPanel()
	{
		mainPanel = new JPanel();
		mainPanel.setPreferredSize(mainPanelSize);
		mainPanel.setBackground(backgroundColor);
		
		CreateTitle();
		CreateCoursesPanel();
	}
	
	public CoursesView() 
	{
		coursesController = new CoursesController(this);
		coursesButton.setForeground(primaryColor);
		CreateMainPanel();
		contentPanel.add(mainPanel);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == logoutButton)
		{
			baseHomeController.NavigateToLogin();
		}
		else if(e.getSource() == coursesButton)
		{
			baseHomeController.NavigateToCourses();
		}
		else if(e.getSource() == profileButton)
		{
			baseHomeController.NavigateToProfile();
		}
		else if(e.getSource() == dashboardButton)
		{
			baseHomeController.NavigateToDashboard();
		}
	}
}
