package model;

import dataServices.AuthenticationService;

public class User {
	private String username;
	private String email;
	private String phoneNumber;
	private String gender;
	private String address;
	private String role;
	private byte[] image;
	
	
	private AuthenticationService authenticationService;
	
	public User() 
	{	
		authenticationService = new AuthenticationService();
	}

	public User Login(String username, String password)
	{
		return authenticationService.Login(username, password);
	}
	
	public boolean CheckUsername(String username)
	{	
		return authenticationService.CheckUsername(username);
	}
	
	public boolean Register(User user, String password)
	{
		return authenticationService.Register(user, password);
	}
	
	public boolean UpdateProfile(User user)
	{
		return authenticationService.UpdateProfile(user);
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
}
