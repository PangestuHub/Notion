package model;

import java.util.ArrayList;

import dataServices.CourseService;

public class Course {
	private String CourseId;
	private String CourseName;
	private String Shift;
	private String ClassName;
	private String ClassId;
	private String Day;
	private int CreditCount;
	
	private CourseService courseService;
	
	public Course() {
		courseService = new CourseService();
	}
	
	private String getStringDay(int day)
	{
		if(day == 1)
		{
			return "Monday";
		}
		else if(day == 2)
		{
			return "Tuesday";
		}
		else if(day == 3)
		{
			return "Wednessday";
		}
		else if(day == 4)
		{
			return "Thursday";
		}
		else if(day == 5)
		{
			return "Friday";
		}
		else if(day == 6)
		{
			return "Saturday";
		}
		else 
		{
			return "Sunday";
		}
	}
	
	public ArrayList<Course> GetCourses(String username)
	{
		return courseService.GetCourses(username);
	}
	
	public ArrayList<Course> GetTodayCourses(String username)
	{
		return courseService.GetTodayCourses(username);
	}
	
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getShift() {
		return Shift;
	}
	public void setShift(String shift) {
		Shift = shift;
	}
	public int getCreditCount() {
		return CreditCount;
	}
	public void setCreditCount(int creditCount) {
		this.CreditCount = creditCount;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(int day) {
		Day = getStringDay(day);
	}
	public String getClassName() {
		return ClassName;
	}
	public void setClassName(String className) {
		ClassName = className;
	}
	public String getClassId() {
		return ClassId;
	}
	public void setClassId(String classId) {
		ClassId = classId;
	}
}
