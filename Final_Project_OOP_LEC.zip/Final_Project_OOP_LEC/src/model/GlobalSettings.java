package model;

public class GlobalSettings {
	public static User me;
	
	public GlobalSettings() {
		
	}
}
