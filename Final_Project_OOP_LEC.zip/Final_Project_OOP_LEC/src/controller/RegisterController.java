package controller;

import static javax.swing.JOptionPane.showMessageDialog;

import model.User;
import view.LoginView;
import view.RegisterView;

public class RegisterController {
	private User user;
	private RegisterView registerView;
	
	public RegisterController(RegisterView registerView)
	{
		user = new User();
		this.registerView = registerView;
	}
	
	public void Login()
	{
		this.registerView.dispose();
		new LoginView();
	}
	
	private boolean isNumeric(String str)
	{
	    for(int i = 0; i < str.length(); i++)
	    {
	    	if(str.charAt(i) < '0' || str.charAt(i) > '9')
	    	{
	    		return false;
	    	}
	    }
	    return true;
	}
	
	private boolean Validation()
	{
		String username = registerView.getUsernameField().getText();
		String email = registerView.getEmailField().getText();
		String phoneNumber = registerView.getPhoneNumberField().getText();
		String address = registerView.getAddressArea().getText();
		String password =  String.valueOf(registerView.getPasswordField().getPassword());
		String confirmPassword = String.valueOf(registerView.getConfirmPasswordField().getPassword());
		
		if(username.isEmpty())
		{
			showMessageDialog(null, "Username Cannot Be Empty");
			return false;
		}
		else if(email.isEmpty())
		{
			showMessageDialog(null, "Email Cannot Be Empty");
			return false;
		}
		else if(phoneNumber.isEmpty())
		{
			showMessageDialog(null, "Phone Number Cannot Be Empty");
			return false;
		}
		else if(address.isEmpty())
		{
			showMessageDialog(null, "Address Cannot Be Empty");
			return false;
		}
		else if(password.isEmpty())
		{
			showMessageDialog(null, "Password Cannot Be Empty");
			return false;
		}
		else if(confirmPassword.isEmpty())
		{
			showMessageDialog(null, "Confirm Password Cannot Be Empty");
			return false;
		}
		
		if(!password.equals(confirmPassword))
		{
			showMessageDialog(null, "Password and Confirm Password Must Same");
			return false;
		}
		else if(!isNumeric(phoneNumber))
		{
			showMessageDialog(null, "Phone Number Must Be Number!");
			return false;
		}
		else if(phoneNumber.length() < 10 || phoneNumber.length() > 12)
		{
			showMessageDialog(null, "Phone Number Must have 10 - 12 Digits!");
			return false;
		}
		else if(user.CheckUsername(username))
		{
			showMessageDialog(null, "Username Has Been Taken!");
			return false;
		}

		
		// validasi number
		
		return true;
	}
	
	public void Register()
	{
		if(!Validation())
		{
			return;
		}
		
		String username = registerView.getUsernameField().getText();
		String email = registerView.getEmailField().getText();
		String phoneNumber = registerView.getPhoneNumberField().getText();
		String gender = registerView.getGenderGroup().getSelection().getActionCommand();
		String address = registerView.getAddressArea().getText();
		String password = String.valueOf(registerView.getPasswordField().getPassword());
		String role = registerView.getRoleBox().getSelectedItem().toString();
		
		User newUser = new User();
		
		newUser.setUsername(username);
		newUser.setEmail(email);
		newUser.setPhoneNumber(phoneNumber);
		newUser.setGender(gender);
		newUser.setAddress(address);
		newUser.setRole(role);
		
		try
		{
			if(user.Register(newUser, password))
			{
				showMessageDialog(null, "Register Succeeded");
				this.registerView.dispose();
				new LoginView();
			}
			else
			{
				showMessageDialog(null, "Register Failed");
			}
		}
		catch(Exception e)
		{
			showMessageDialog(null, e.getMessage());
		}
		
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
