package controller;

import static javax.swing.JOptionPane.showMessageDialog;

import model.GlobalSettings;
import model.User;
import view.ProfileView;

public class ProfileController {
	
	private ProfileView profileView;
	
	public ProfileController(ProfileView profileView) {
		this.profileView = profileView;
	}
	
	public void SetToDefault()
	{
		profileView.getUsernameField().setText(GlobalSettings.me.getUsername());
		profileView.getEmailField().setText(GlobalSettings.me.getEmail());
		profileView.getAddressArea().setText(GlobalSettings.me.getAddress());
		profileView.getPhoneNumberField().setText(GlobalSettings.me.getPhoneNumber());
	}
	
	private boolean isNumeric(String str)
	{
	    for(int i = 0; i < str.length(); i++)
	    {
	    	if(str.charAt(i) < '0' || str.charAt(i) > '9')
	    	{
	    		return false;
	    	}
	    }
	    return true;
	}
	
	private boolean Validation()
	{
		String email = profileView.getEmailField().getText();
		String address = profileView.getAddressArea().getText();
		String phoneNumber = profileView.getPhoneNumberField().getText();
		
		if(email.isEmpty())
		{
			showMessageDialog(null, "Email Cannot Be Empty");
			return false;
		}
		else if(phoneNumber.isEmpty())
		{
			showMessageDialog(null, "Phone Number Cannot Be Empty");
			return false;
		}
		else if(address.isEmpty())
		{
			showMessageDialog(null, "Address Cannot Be Empty");
			return false;
		}
		else if(!isNumeric(phoneNumber))
		{
			showMessageDialog(null, "Phone Number Must Be Number!");
			return false;
		}
		else if(phoneNumber.length() < 10 || phoneNumber.length() > 12)
		{
			showMessageDialog(null, "Phone Number Must have 10 - 12 Digits!");
			return false;
		}
		
		return true;
	}
	
	public void UpdateProfile()
	{
		if(!Validation())
		{
			return;
		}
		User updateUser = new User();
		
		updateUser.setUsername(GlobalSettings.me.getUsername());
		updateUser.setEmail(profileView.getEmailField().getText());
		updateUser.setAddress(profileView.getAddressArea().getText());
		updateUser.setPhoneNumber(profileView.getPhoneNumberField().getText());
		
		if(updateUser.UpdateProfile(updateUser))
		{
			showMessageDialog(null, "Profile Updated");
		}
	}
}
