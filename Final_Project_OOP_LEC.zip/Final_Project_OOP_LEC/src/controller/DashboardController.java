package controller;

import java.util.ArrayList;

import model.Course;
import model.GlobalSettings;
import view.DashboardView;

public class DashboardController {
	
	private DashboardView dashboardView;
	private Course course;
	
	public DashboardController(DashboardView dashboardView) 
	{
		this.dashboardView = dashboardView;
		course = new Course();
	}
	
	public ArrayList<Course> GetTodayCourses()
	{
		return course.GetTodayCourses(GlobalSettings.me.getUsername());
	}
}
