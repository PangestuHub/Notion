package controller;

import view.BaseHomeView;
import view.CoursesView;
import view.DashboardView;
import view.LoginView;
import view.ProfileView;

public class BaseHomeController {
	private BaseHomeView baseHomeView;
	
	public BaseHomeController(BaseHomeView baseHomeView){
		this.baseHomeView = baseHomeView;
	}
	
	public void NavigateToLogin()
	{
		this.baseHomeView.dispose();
		new LoginView(); 
	}
	
	public void NavigateToCourses()
	{
		this.baseHomeView.dispose();
		new CoursesView(); 
	}
	
	public void NavigateToProfile()
	{
		this.baseHomeView.dispose();
		new ProfileView(); 
	}
	
	public void NavigateToDashboard()
	{
		this.baseHomeView.dispose();
		new DashboardView(); 
	}
}
