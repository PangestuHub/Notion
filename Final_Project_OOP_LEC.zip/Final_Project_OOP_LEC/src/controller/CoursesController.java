package controller;

import java.util.ArrayList;

import model.Course;
import model.GlobalSettings;
import view.CoursesView;

public class CoursesController {
	CoursesView coursesView;
	Course course;
	
	public CoursesController(CoursesView coursesView){
		this.coursesView = coursesView;
		course = new Course();
	}
	
	public ArrayList<Course> GetCourses()
	{
		return course.GetCourses(GlobalSettings.me.getUsername());
	}
}
