package controller;

import static javax.swing.JOptionPane.showMessageDialog;

import model.User;
import view.*;

public class LoginController {
	private User user;
	private LoginView loginView;
	
	public LoginController(LoginView loginView)
	{
		user = new User();
		this.loginView = loginView;
	}
	
	public void Login()
	{
		String username = loginView.getUsernameField().getText();
		String password = String.valueOf(loginView.getPasswordField().getPassword());
		if(user.Login(username, password) != null)
		{
			showMessageDialog(null , "Login Success!");
			this.loginView.dispose();
			new DashboardView();
			return;
		}
		else
		{
			showMessageDialog(null , "User Not Found!");
		}
	}
	
	public void Register()
	{
		this.loginView.dispose();
		new RegisterView();
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
}
